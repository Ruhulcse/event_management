INSERT INTO `reservations`(`id`, `name`, `email`, `workshop_id`) VALUES (1, 'Ruhul Amin', 'ruhul.cse123@gmail.com', 2);
INSERT INTO `reservations`(`id`, `name`, `email`, `workshop_id`) VALUES (2, 'Abir Hasan', 'abircu@gmail.com', 2);
INSERT INTO `reservations`(`id`, `name`, `email`, `workshop_id`) VALUES (3, 'Aysha Akter', 'itsaysa@gmail.com', 1);
INSERT INTO `reservations`(`id`, `name`, `email`, `workshop_id`) VALUES (4, 'Marzia Momo', 'momo@gmail.com', 1);
INSERT INTO `reservations`(`id`, `name`, `email`, `workshop_id`) VALUES (5, 'Rakib', 'rakib@gmail.com', 1);
