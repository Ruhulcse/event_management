INSERT INTO `workshops`(`id`, `event_id`, `start_at`, `end_at`, `title`, `description`) VALUES (1, 1, '2022-11-27 16:35:53', '2022-11-28 16:36:05', 'introduction to javascript', 'basic javascript');
INSERT INTO `workshops`(`id`, `event_id`, `start_at`, `end_at`, `title`, `description`) VALUES (2, 1, '2022-11-27 16:35:53', '2022-11-28 16:36:05', 'Basic js', 'basic js description');
INSERT INTO `workshops`(`id`, `event_id`, `start_at`, `end_at`, `title`, `description`) VALUES (3, 1, '2022-11-27 16:35:53', '2022-11-28 16:36:05', 'Array in Js', 'Array in JS description');
